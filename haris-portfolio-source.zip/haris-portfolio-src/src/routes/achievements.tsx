import { createFileRoute } from '@tanstack/react-router';
import { AchievementsSection } from '@/components/portfolio-sections';
import { pageHead } from '@/lib/portfolio';
export const Route=createFileRoute('/achievements')({head:()=>pageHead('Achievements','Haris Jagrala’s cricket league achievements and participation in aptitude and awareness competitions.'),component:Page});
function Page(){return <div className="reveal"><div className="site-width page-intro"><div className="eyebrow">ACHIEVEMENTS</div><h1>Milestones along the way.</h1><p className="subcopy">Haris Jagrala’s cricket league achievements and participation in aptitude and awareness competitions.</p></div><AchievementsSection/></div>}
