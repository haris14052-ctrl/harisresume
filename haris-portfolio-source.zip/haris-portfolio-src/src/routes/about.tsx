import { createFileRoute } from '@tanstack/react-router';
import { AboutSection } from '@/components/portfolio-sections';
import { pageHead } from '@/lib/portfolio';
export const Route=createFileRoute('/about')({head:()=>pageHead('About me','Meet Haris Jagrala, a PGDM student, finance graduate, class representative and fragrance entrepreneur.'),component:Page});
function Page(){return <div className="reveal"><div className="site-width page-intro"><div className="eyebrow">ABOUT ME</div><h1>Curiosity with a purpose.</h1><p className="subcopy">Meet Haris Jagrala, a PGDM student, finance graduate, class representative and fragrance entrepreneur.</p></div><AboutSection/></div>}
