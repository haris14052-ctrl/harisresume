import { createFileRoute } from '@tanstack/react-router';
import { ProjectsSection } from '@/components/portfolio-sections';
import { pageHead } from '@/lib/portfolio';
export const Route=createFileRoute('/projects')({head:()=>pageHead('Projects & explorations','Explore Haris’s Demat 2.0 finance report, Access360 hackathon concept and business case-study activities.'),component:Page});
function Page(){return <div className="reveal"><div className="site-width page-intro"><div className="eyebrow">PROJECTS & EXPLORATIONS</div><h1>Ideas grounded in research.</h1><p className="subcopy">Explore Haris’s Demat 2.0 finance report, Access360 hackathon concept and business case-study activities.</p></div><ProjectsSection/></div>}
