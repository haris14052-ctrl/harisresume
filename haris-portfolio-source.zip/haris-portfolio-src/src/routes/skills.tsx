import { createFileRoute } from '@tanstack/react-router';
import { SkillsSection } from '@/components/portfolio-sections';
import { pageHead } from '@/lib/portfolio';
export const Route=createFileRoute('/skills')({head:()=>pageHead('Skills & learning','Haris Jagrala’s verified finance, research, communication and software skills, courses and certifications.'),component:Page});
function Page(){return <div className="reveal"><div className="site-width page-intro"><div className="eyebrow">SKILLS & LEARNING</div><h1>The tools. The mindset. The drive.</h1><p className="subcopy">Haris Jagrala’s verified finance, research, communication and software skills, courses and certifications.</p></div><SkillsSection/></div>}
