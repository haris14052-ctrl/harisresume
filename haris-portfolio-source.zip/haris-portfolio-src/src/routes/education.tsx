import { createFileRoute } from '@tanstack/react-router';
import { EducationSection } from '@/components/portfolio-sections';
import { pageHead } from '@/lib/portfolio';
export const Route=createFileRoute('/education')({head:()=>pageHead('Education','Explore Haris Jagrala’s education at IMDR Pune, Burhani College, Maharashtra College and N. M. T. Academy.'),component:Page});
function Page(){return <div className="reveal"><div className="site-width page-intro"><div className="eyebrow">EDUCATION</div><h1>Learning today. Leading tomorrow.</h1><p className="subcopy">Explore Haris Jagrala’s education at IMDR Pune, Burhani College, Maharashtra College and N. M. T. Academy.</p></div><EducationSection/></div>}
