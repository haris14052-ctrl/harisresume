import { createFileRoute } from '@tanstack/react-router';
import { AzmaarSection } from '@/components/portfolio-sections';
import { pageHead } from '@/lib/portfolio';
export const Route=createFileRoute('/azmaar')({head:()=>pageHead('Azmaar Fragrance','Discover Azmaar Fragrance, Haris Jagrala’s venture in non-alcoholic perfumes, attars and pocket perfumes.'),component:Page});
function Page(){return <div className="reveal"><div className="site-width page-intro"><div className="eyebrow">AZMAAR FRAGRANCE</div><h1>An idea. A brand. My venture.</h1><p className="subcopy">Discover Azmaar Fragrance, Haris Jagrala’s venture in non-alcoholic perfumes, attars and pocket perfumes.</p></div><AzmaarSection/></div>}
