export const linkedin = "https://linkedin.com/in/haris-jagrala-5b709a250";
export const instagram = "https://instagram.com/azmaarfragranceofficial";
export const email = "haris14052@gmail.com";
export const gmailCompose = `https://mail.google.com/mail/?view=cm&fs=1&to=${email}&su=${encodeURIComponent("Hello Haris")}&body=${encodeURIComponent("Hi Haris,\n\n")}`;
export const education = [
  { degree: "Post Graduate Diploma in Management", field: "PGDM · Finance", school: "Institute of Management Development & Research (IMDR), Pune", year: "Pursuing", score: "Current" },
  { degree: "Bachelor of Management Studies", field: "BMS · Finance", school: "Burhani College", year: "2025", score: "7.02 / 10 CGPA" },
  { degree: "Higher Secondary Certificate", field: "HSC", school: "Maharashtra College", year: "2022", score: "75%" },
  { degree: "Secondary School Certificate", field: "SSC", school: "N. M. T. Academy", year: "2020", score: "72%" },
];
export const projects = [
  { number: "01", category: "FINANCE RESEARCH", name: "Demat 2.0", subtitle: "Is India Entering the Era of Tokenised Securities?", description: "A MyFinance report researching securities tokenisation and the SEBI–RBI pilot for corporate bonds.", tags: ["Financial markets", "Research", "Tokenisation"], icon: "finance" },
  { number: "02", category: "SOCIAL INNOVATION", name: "Access360", subtitle: "Smart India Hackathon · Shortlisted team", description: "Presented a concept designed to improve access to government schemes for persons with disabilities.", tags: ["Problem-solving", "Accessibility", "Teamwork"], icon: "access" },
  { number: "03", category: "BUSINESS & STRATEGY", name: "From cases to conversations", subtitle: "Business case studies & institute activities", description: "Participated in business case-study presentations, an agri-business case competition, IMDR's ZeroPointFive entrepreneurship summit and Eco Club activities.", tags: ["Case studies", "Entrepreneurship", "Presentation"], icon: "business" },
];
export const skillGroups = [
  { title: "Finance & analysis", icon: "finance", skills: ["Basic financial analysis", "Financial markets awareness", "Business research", "Analytical problem-solving"] },
  { title: "Tools & technology", icon: "tools", skills: ["Excel · basic to intermediate", "Advanced Excel coursework", "Microsoft Word & PowerPoint", "Canva", "AI tools for research & productivity"] },
  { title: "People & execution", icon: "people", skills: ["Business communication", "Presentation skills", "Teamwork & collaboration", "Leadership", "Event coordination", "Time management & adaptability"] },
];
export const achievements = [
  { title: "Cricket League Winner", detail: "Burhani College Cricket League · Edition 4", date: "January 2025", type: "Winner" },
  { title: "Cricket League Runner-up", detail: "Burhani College Cricket League · Edition 2", date: "March 2023", type: "Runner-up" },
  { title: "National Aptitude Challenge", detail: "Times NIE", date: "2016–2017", type: "Participant" },
  { title: "Cancer Awareness Drawing Competition", detail: "Wockhardt Hospitals, Mumbai", date: "2015", type: "Participant" },
];
export const cvFacts = JSON.stringify({
  name: "Haris Esa Mohammed Jagrala", email, linkedin, instagram,
  summary: "PGDM student at IMDR Pune with BMS Finance from Burhani College. Interested in finance, financial markets, business operations and entrepreneurship. Seeking internship or entry-level opportunities to apply analytical, communication, research and coordination skills.",
  education, projects, skillGroups, achievements,
  venture: { role: "Founder", name: "Azmaar Fragrance", description: "Developing a fragrance venture focused on non-alcoholic perfumes, attars and pocket perfumes. Worked on product concepts, pricing, packaging, brand identity and social media promotion. Explored product positioning and customer-facing brand communication." },
  leadership: ["Class Representative at IMDR Pune: supports class communication, coordination and participation in campus activities; communication between classmates and the institute.", "Community Sports Event Organiser: helped coordinate local cricket events including Muman Samaj Premier League (MSPL) and Murga Giran Premier League (MGPL), supporting coordination and teamwork."],
  certifications: ["Accounts Assistant Course, Gandin Institute of Computer Education, 2023: MS Office, Excel, Tally Prime with GST", "MS Office and Advanced Excel, A-TEK IT Education, 2022", "Python Programming, Udemy, in progress"],
  languages: ["English", "Hindi", "Marathi", "Gujarati", "Urdu"],
  interests: ["Finance and investments", "Entrepreneurship and business development", "Cricket", "Branding and marketing", "Fragrance and brand building", "Emerging technologies"],
});
export function pageHead(section: string, description: string) {
  const title = `${section} — Haris Jagrala | Finance & Entrepreneurship`;
  return { meta: [{ title }, { name: "description", content: description }, { property: "og:title", content: title }, { property: "og:description", content: description }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] };
}