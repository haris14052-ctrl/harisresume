# Portfolio roadmap
- [x] Build CV-based portfolio and all requested sections with uploaded media and contact/resume links.
- [x] Add a live CV assistant with one conversation and no saved history.
- [x] Verify navigation, privacy, media, chat, and mobile layout.
- [x] Feature the Azmaar Instagram page and show a single Azmaar product image.
