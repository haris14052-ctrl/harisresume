<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Application architecture
- Public portfolio sections use individual TanStack file routes with shared site navigation and reusable CV content, so each section is directly shareable.
- Keep the verified CV facts in a single browser-safe data module; the server assistant uses that same source to prevent factual drift.
- The CV assistant uses AI SDK UI-message streaming through a public TanStack server route with validated text-only input; no visitor conversations are persisted.
- Uploaded media is served through asset pointer files; fragrance promotional images are physically cropped before upload to exclude private contact information.
